﻿namespace SimpleTaskSystem
{
    public class SimpleTaskSystemConsts
    {
        public const string LocalizationSourceName = "SimpleTaskSystem";

        public const string ConnectionStringName = "Default";
    }
}
﻿(function ($) {

    $(function() {
        //...
    });

})(jQuery);
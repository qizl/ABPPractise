namespace SimpleTaskSystem.Web.Controllers
{
    public class LayoutController : SimpleTaskSystemControllerBase
    {

    }
}
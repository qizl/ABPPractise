﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using SimpleTaskSystem.Configuration;
using SimpleTaskSystem.Web;

namespace SimpleTaskSystem.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class SimpleTaskSystemDbContextFactory : IDesignTimeDbContextFactory<SimpleTaskSystemDbContext>
    {
        public SimpleTaskSystemDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<SimpleTaskSystemDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            SimpleTaskSystemDbContextConfigurer.Configure(builder, configuration.GetConnectionString(SimpleTaskSystemConsts.ConnectionStringName));

            return new SimpleTaskSystemDbContext(builder.Options);
        }
    }
}

using Microsoft.AspNetCore.Antiforgery;
using SimpleTaskSystem.Controllers;

namespace SimpleTaskSystem.Web.Host.Controllers
{
    public class AntiForgeryController : SimpleTaskSystemControllerBase
    {
        private readonly IAntiforgery _antiforgery;

        public AntiForgeryController(IAntiforgery antiforgery)
        {
            _antiforgery = antiforgery;
        }

        public void GetToken()
        {
            _antiforgery.SetCookieTokenAndHeader(HttpContext);
        }
    }
}
